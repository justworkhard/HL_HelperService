// This file is created by egg-ts-helper@1.25.9
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportHelperWords = require('../../../app/controller/helperWords');
import ExportHome = require('../../../app/controller/home');
import ExportNews = require('../../../app/controller/news');
import ExportUser = require('../../../app/controller/user');

declare module 'egg' {
  interface IController {
    helperWords: ExportHelperWords;
    home: ExportHome;
    news: ExportNews;
    user: ExportUser;
  }
}
